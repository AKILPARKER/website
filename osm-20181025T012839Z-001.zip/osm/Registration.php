<?php
session_start();
session_destroy(); 
$msg = "";
if( $_POST ){
	$servername = "localhost:3306";
	$username = "root";
	$password = "";
	$dbname = "webpagedb";

	$conn = mysqli_connect($servername,$username,$password,$dbname);
	
	if (!$conn) 
	{
		die("Connection failed: " . mysqli_connect_error());
	}
	
	$validation_flag = 1;
	
	if( $_POST['email'] == " " ){
		$validation_flag = 0;
		$msg = "Registration number cannot be blank";
	} else if( $_POST['pass'] == "" ){
		$validation_flag = 0;
		$msg = "Password cannot be blank";
	} else if( $_POST['email'] == "" ){
		$validation_flag = 0;
		$msg = "Email cannot be blank";
	} else if( $_POST['pass'] !== $_POST['repass'] ){
		$validation_flag = 0;
		$msg = "Password and Re-entered Passwords do not match.";
	}
	if(!$validation_flag){echo $msg;}
	
	if( $validation_flag ){
		$select_sql = "SELECT * FROM `web` WHERE `email` = '".$_POST['email']."'" ;
		$select_result = mysqli_query( $conn, $select_sql );	
		if( !$select_result ){
			$msg = "Error: " . "<br>" . mysqli_error($conn);
		} else if( $select_result->num_rows ){
			$msg = "The user with registration number '". $_POST['email'] ."' is already registered.";
		} else {
			$insert_sql = "INSERT INTO `web` ( `firstname`, `secondname`, `pass`,'repass', `email`,'date' )
			VALUES ('". $_POST['firstname'] ."', '". $_POST['secondname'] ."', '". $_POST['pass'] ."', '". $_POST['repass'] ."', '". $_POST['email'] ."', '". $_POST['date'] ."' )";
			if ( mysqli_query($conn, $insert_sql) ) {
				header('Location: SIGNUP.html');
			} else {
				$msg = "Error: " . "<br>" . mysqli_error($conn);
			}
		}
	}
    echo "Account Successfully Created";
	 header("Location: login.html");
	
	mysqli_close($conn);
}
?>