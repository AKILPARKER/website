<?php
	session_start();
	$msg = "";
	if( $_POST ){
		$servername = "localhost:3306";
		$username = "root";
		$password = "";
		$dbname = "webpagedb";

		$conn = mysqli_connect($servername, $username, $password, $dbname);
		
		if (!$conn) {
			die("Connection failed: " . mysqli_connect_error());
		}
		$validation_flag = 1;
		
		if( $_POST['user'] == "" ){
			$validation_flag = 0;
			$msg = "Username name cannot be blank";
			echo $msg;
		} else if( $_POST['pass'] == "" ){
			$validation_flag = 0;
			$msg = "Password cannot be blank";
			echo $msg;
		}
		
		if( $validation_flag ){
			$select_sql = "SELECT * FROM web WHERE `username` = '".$_POST['user']."' AND `password` = '".$_POST['pass']."'" ;
			$select_result = mysqli_query( $conn, $select_sql );
			if( !$select_result )
			{
				$msg = "Error: "  . "<br>" . mysqli_error($conn);
			} 
			else if( $select_result->num_rows )
			{
				$row = $select_result->fetch_assoc();
				$_SESSION["user_id"] = $row['id'];
				echo "Successful Login";
				//header('Location: profile.php');
			} 
			else 
			{
				$msg = "The username/password combination do not match.";
				echo $msg;
			}
		}
		mysqli_close($conn);
	}

?>