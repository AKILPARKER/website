<?php

$user = 'root';
$pass = '';
$db = 'webpagedb';

$db = new mysqli('localhost',$user,$pass,$db) or die ("Unable to connect");

echo"Great!!!";

?>