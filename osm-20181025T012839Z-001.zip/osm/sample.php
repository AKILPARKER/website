<?php
echo'hi';
     $firstname=$_POST["firstname"];
$a=5;
echo $firstname;
echo $a;
?>h