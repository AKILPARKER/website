<?php
$username=filter_input(INPUT_POST, 'username');
$password=filter_input(INPUT_POST, 'pass');
$reenterpassword=filter_input(INPUT_POST, 'repass');
$email=filter_input(INPUT_POST, 'email');
if(!empty($username)){
if(!empty($password)){
if(!empty($email)){
$host="localhost";
$dbusername='root';
$dbpassword='';
$dbname="webpagedb";

$conn= new mysqli($host, $dbusername, $dbpassword, $dbname);

if(mysqli_connect_error()){
die('(connect Error('.mysqli_connect_errno().')'.mysqli_connecr_error());
}
else{
$sql ="INSERT INTO web(username,pass,repass,email)VALUES('$username','$password','$reenterpassword','$email')";
if($conn->query($sql)){
echo "Newe Record is Successfully Inserted";
}
else{
echo "Error".$sql.'<br>'.$conn->error;
}
$conn->close();
}
}
else{
echo"E-mail must be filled";
die();
}
}
else
{
echo"Password Should be filled";
die();
}
}
else{
echo"Username Should be filled";
die();
}
 header("Location: login.html");
?>